//
//  WeatherViewController.swift
//  WeatherForecastApp
//
//  Created by Narayanasamy on 28/12/23.
//

import UIKit
import CoreLocation


class CurrentWeatherViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var tempLbl: UILabel!
    
    
    @IBOutlet weak var humidityLbl: UILabel!
    
    @IBOutlet weak var windLbl: UILabel!
    
    @IBOutlet weak var pressureLbl: UILabel!
    
    @IBOutlet weak var descriptionLbl: UILabel!
    
    
    @IBOutlet weak var backgroundView: UIView!{
        didSet{
            backgroundView.layer.cornerRadius = 12
            backgroundView.layer.masksToBounds = true
        }
    }
    
    
    var viewModel = CurrentWeatherViewModel()
    var locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupLocationManager()
        // getLocationAndUpdateWeather()
    }
    
    @IBAction func gpsLocationBtn(_ sender: UIButton) {
        //            checkLocationAuthorization { authorized in
        //                if authorized {
        //
        //                }
    }
    
    
    func setupLocationManager() {
        self.locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
    }
    
    func updateUI(with weather: WeatherModel) {
        guard let temperature = weather.main?.temp else {
            print("Temperature data not available.")
            tempLbl.text = "N/A"
            return
        }
        
        tempLbl.text = "\(temperature)°C"
        humidityLbl.text = "Humidity: \(weather.main?.humidity ?? 0)%"
        windLbl.text = "Wind: \(weather.wind?.speed ?? 0) m/s"
        pressureLbl.text = "Pressure: \(weather.main?.pressure ?? 0) hPa"
        descriptionLbl.text = weather.weather?.first?.description ?? "No Description"
    }
    
    func showLocationDeniedAlert() {
        // Your code to display an alert indicating that location services are not available
    }
    
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        switch manager.authorizationStatus {
        case .authorizedAlways, .authorizedWhenInUse:
            DispatchQueue.global().async { [weak self] in
                self?.getLocationAndUpdateWeather()
            }
        case .denied, .restricted:
            showLocationDeniedAlert()
        case .notDetermined:
            DispatchQueue.global().async { [weak self] in
                self?.locationManager.requestWhenInUseAuthorization()
            }
        @unknown default:
            break
        }
    }
        
        
        
        //        func checkLocationAuthorization(completion: @escaping (Bool) -> Void) {
        //            let status = CLLocationManager.authorizationStatus()
        //
        //            switch status {
        //            case .authorizedWhenInUse, .authorizedAlways:
        //                completion(true)
        //            case .denied, .restricted:
        //                showLocationDeniedAlert()
        //                completion(false)
        //            case .notDetermined:
        //                DispatchQueue.global().async { [weak self] in
        //                    self?.locationManager.requestWhenInUseAuthorization()
        //                    completion(false)
        //                }
        //            @unknown default:
        //                completion(false)
        //            }
        //        }
        
    func getLocationAndUpdateWeather() {
        guard CLLocationManager.locationServicesEnabled() else {
            print("Location services are not enabled.")
            return
        }

        guard let location = locationManager.location else {
            print("Location not available yet. Waiting for updates...")
            return
        }

        // Ensure the location has valid coordinates
        guard location.coordinate.latitude != 0.0 && location.coordinate.longitude != 0.0 else {
            print("Invalid coordinates. Waiting for valid location updates...")
            return
        }
        
        print(location.coordinate.latitude, location.coordinate.longitude)

        viewModel.fetchCurrentWeather(forLatitude: location.coordinate.latitude, longitude: location.coordinate.longitude) { [weak self] result in
            switch result {
            case .success(let weather):
                print("Weather fetched successfully: \(weather)")
                DispatchQueue.main.async {
                    self?.updateUI(with: weather)
                }
            case .failure(let error):
                print("Error fetching weather: \(error.localizedDescription)")
            }
        }
    }

    
}
    // MARK: - CLLocationManagerDelegate
    extension CurrentWeatherViewController {
        func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
            if status == .authorizedWhenInUse || status == .authorizedAlways {
                DispatchQueue.global().async { [weak self] in
                    self?.getLocationAndUpdateWeather()
                }
            } else {
                showLocationDeniedAlert()
            }
        }

        func locationManager(manager: CLLocationManager, didFailWithError error: Error) {
            print("Location manager error: \(error.localizedDescription)")
        }
        // ... (your existing locationManager delegate methods)
    }
